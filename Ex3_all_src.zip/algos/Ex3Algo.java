package algos;

import server.Game;
import server.GhostCL;
import server.PacManAlgo;
import server.PacmanGame;
import utils.Index2D;
import utils.Map;
import utils.Map2D;
import utils.Pixel2D;

import java.awt.*;

/**
 * This is the major algorithmic class for Ex3 - the PacMan game:
 *
 * This code is a very simple example (random-walk algorithm).
 * Your task is to implement (here) your PacMan algorithm.
 */
public class Ex3Algo implements PacManAlgo {
	private int _count;
    private Pixel2D pacmanPos;
    private Map2D map;

    private static final int CODE = 0;
    private static final int BLUE = Game.getIntColor(Color.BLUE, CODE);
    private static final int PINK = Game.getIntColor(Color.PINK, CODE);
    private static final int GREEN = Game.getIntColor(Color.GREEN, CODE);
    private static final int BLACK = Game.getIntColor(Color.BLACK, CODE);

    /**
     * Constructs a new automatic Pac-Man algorithm.
     */
	public Ex3Algo() {_count=0;}

	@Override
	/**
	 *  Add a short description for the algorithm as a String.
	 */
	public String getInfo() {
		return "This is a automatic algorithm for the PacMan.";
	}

	@Override
    /**
     * Computes the next move of the Pac-Man.
     *
     * The method analyzes the current game state and applies
     * a prioritized decision logic:
     * escape → eat ghosts → collect power dots → collect points.
     *
     * @param game the current Pac-Man game instance
     * @return an integer representing the chosen movement direction
     */
	public int move(PacmanGame game) {
		if(_count==0 || _count==300) {
			int[][] board = game.getGame(0);
			printBoard(board);
			System.out.println("Blue=" + BLUE + ", Pink=" + PINK + ", Black=" + BLACK + ", Green=" + GREEN);
			String pos = game.getPos(CODE).toString();
			System.out.println("Pacman coordinate: "+pos);
			GhostCL[] ghosts = game.getGhosts(CODE);
			printGhosts(ghosts);

            // Parse Pac-Man position
            String[] p = pos.split(",");
            int x = Integer.parseInt(p[0]);
            int y = Integer.parseInt(p[1]);
            pacmanPos = new Index2D(x, y);
            map = new Map(board);

            Map2D dists = map.allDistance(pacmanPos, BLUE);

            // Mode 1: Escape from black ghosts
            int dir = escapeFromBlackGhosts(ghosts, dists);
            if(dir != Game.STAY) return dir;

            // Mode 2: Eat white (eatable) ghosts
            dir = eatWhiteGhosts(ghosts, dists);
            if(dir != Game.STAY) return dir;

            // Mode 3: Go to green ONLY if green is NOT already active
            if(!isGreenActive(ghosts)) {
                Pixel2D[] closestGreenPath = closestTargetPath(GREEN);
                if(closestGreenPath != null && closestGreenPath.length > 1) {
                    int distToGreen = dists.getPixel(
                            closestGreenPath[closestGreenPath.length - 1]
                    );

                    // go to green only if it is close enough
                    if(distToGreen >= 0 && distToGreen < 4) {
                        return directionTo(closestGreenPath[1]);
                    }
                }
            }

            // Mode 4: Collect pink points
            Pixel2D[] closestPinkPath = closestTargetPath(PINK);
            if(closestPinkPath != null && closestPinkPath.length > 1)
                return directionTo(closestPinkPath[1]);
		}

		_count++;
		return randomDir();
	}

    /**
     * Prints the game board to the console.
     */
	private static void printBoard(int[][] b) {
		for(int y =0;y<b[0].length;y++){
			for(int x =0;x<b.length;x++){
				int v = b[x][y];
				System.out.print(v+"\t");
			}
			System.out.println();
		}
	}

    /**
     * Prints ghosts information to the console.
     */
	private static void printGhosts(GhostCL[] gs) {
		for(int i=0;i<gs.length;i++){
			GhostCL g = gs[i];
			System.out.println(i+") status: "+g.getStatus()+",  type: "+g.getType()+",  pos: "+g.getPos(0)+",  time: "+g.remainTimeAsEatable(0));
		}
	}

    /**
     * Chooses a random legal direction.
     *
     * @return a random movement direction
     */
	private static int randomDir() {
		int[] dirs = {Game.UP, Game.LEFT, Game.DOWN, Game.RIGHT};
		int ind = (int)(Math.random()*dirs.length);
		return dirs[ind];
	}

    /**
     * Checks if any ghost is currently eatable.
     *
     * @param ghosts array of ghosts
     * @return true if at least one ghost is eatable
     */
    private boolean isGreenActive(GhostCL[] ghosts) {
        for(GhostCL g : ghosts) {
            if(g.remainTimeAsEatable(CODE) > 0)
                return true;
        }
        return false;
    }

    /**
     * Attempts to escape from the closest dangerous ghost.
     *
     * @param ghosts array of ghosts
     * @param dists distance map from Pac-Man
     * @return escape direction or STAY if no threat exists
     */
    private int escapeFromBlackGhosts(GhostCL[] ghosts, Map2D dists) {
        int minGhostPath = -1;
        Pixel2D closestGhost = null;

        // check every ghost
        for(GhostCL g : ghosts) {
            // if the ghost is white - eatable
            if(g.remainTimeAsEatable(CODE) > 0) continue;

            // get the current ghost pixel
            String[] ghostPos = g.getPos(CODE).toString().split(",");
            Pixel2D ghostPixel = new Index2D(Integer.parseInt(ghostPos[0]), Integer.parseInt(ghostPos[1]));

            if(map.getPixel(ghostPixel) == BLUE || map.getPixel(ghostPixel) == BLACK) continue;

            // find the shortest path from the pacman to the current ghost
            Pixel2D[] ghostPath = map.shortestPath(pacmanPos, ghostPixel, BLUE);
            int ghostPathLength = ghostPath.length;

            // find the closest ghost - the smallest path between the pacman and the ghost
            if(minGhostPath == -1 || minGhostPath > ghostPathLength) {
                minGhostPath = ghostPathLength;
                closestGhost = ghostPixel;
            }
        }

        // if I haven't found any ghosts of the smallest path from the pacman to a ghost is smaller than 6 - ignore
        if(closestGhost == null || minGhostPath >= 6) return Game.STAY;

        return escapeGhost(closestGhost, dists);
    }

    /**
     * Selects the direction that maximizes distance from a ghost.
     *
     * @param ghost the threatening ghost
     * @param dists distance map
     * @return safest movement direction
     */
    private int escapeGhost(Pixel2D ghost, Map2D dists) {
        int bestDir = Game.STAY;
        int bestDist = dists.getPixel(ghost);

        int[] dirs = {Game.UP, Game.DOWN, Game.LEFT, Game.RIGHT};

        // check every direction the ghost can do
        for(int dir : dirs) {
            Pixel2D next = pixelStep(pacmanPos, dir);
            // check if the pixel is valid
            if(!map.isInside(next)) continue;
            if(map.getPixel(next) == BLUE) continue;

            // check the distance between the pacman and the ghost
            int ghostD = map.allDistance(next, BLUE).getPixel(ghost);
            // find the biggest distance
            if(ghostD > bestDist) {
                bestDist = ghostD;
                bestDir = dir;
            }
        }

        return bestDir;
    }

    /**
     * Computes the next pixel according to direction (cyclic movement).
     */
    private Pixel2D pixelStep(Pixel2D from, int dir) {
        int x = from.getX();
        int y = from.getY();

        int w = map.getWidth();
        int h = map.getHeight();

        if(dir == Game.UP) {
            y = (y + 1) % h;
        }
        else if(dir == Game.DOWN) {
            y = (y - 1 + h) % h;
        }
        else if(dir == Game.LEFT) {
            x = (x - 1 + w) % w;
        }
        else if(dir == Game.RIGHT) {
            x = (x + 1) % w;
        }

        return new Index2D(x, y);
    }

    /**
     * Finds the shortest path to the closest pixel of a given color.
     *
     * @param color target color
     * @return path to the closest target or null if none exists
     */
    private Pixel2D[] closestTargetPath(int color) {
        Pixel2D[] ans = null;
        int minPath = -1;

        for (int x = 0; x < map.getWidth(); x++) {
            for (int y = 0; y < map.getHeight(); y++) {
                Pixel2D currPixel = new Index2D(x,y);
                int currPixelColor = map.getPixel(currPixel);

                if(currPixelColor == color) {
                    Pixel2D[] path = map.shortestPath(pacmanPos, currPixel, BLUE);
                    if(path != null && path.length > 1) {
                        int pathLength = path.length;

                        if(minPath == -1 || minPath > pathLength) {
                            minPath = pathLength;
                            ans = path;
                        }
                    }
                }
            }
        }
        return ans;
    }

    /**
     * Attempts to chase and eat white ghosts.
     *
     * @param ghosts array of ghosts
     * @param dists distance map
     * @return movement direction or STAY if not possible
     */
    private int eatWhiteGhosts(GhostCL[] ghosts, Map2D dists) {
        Pixel2D target = null;
        int minDist = Integer.MAX_VALUE;

        for(GhostCL g : ghosts) {
            double time = g.remainTimeAsEatable(CODE);
            if(time <= 0) continue; // isn't a white ghost

            // get the white ghost pixel
            String[] ghostPos = g.getPos(CODE).toString().split(",");
            Pixel2D ghostPixel = new Index2D(Integer.parseInt(ghostPos[0]), Integer.parseInt(ghostPos[1]));
            int ghostDist = dists.getPixel(ghostPixel);

            // check if this ghost is the closest and the pacman has enough time to eat the ghost,
            // and the white ghost is close to the pacman - 4 squares long
            if(ghostDist >= 0 && ghostDist < minDist && ghostDist < time - 2) {
                minDist = ghostDist;
                target = ghostPixel;
            }
        }

        if(target == null) return Game.STAY;

        Pixel2D[] path = map.shortestPath(pacmanPos, target, BLUE);
        if(path == null || path.length <= 3) return Game.STAY;

        return directionTo(path[1]);
    }

    /**
     * Converts a neighboring pixel into a movement direction.
     *
     * @param next the next pixel on the path
     * @return movement direction
     */
    private int directionTo(Pixel2D next) {
        int px = pacmanPos.getX();
        int py = pacmanPos.getY();

        int nx = next.getX();
        int ny = next.getY();

        int w = map.getWidth();
        int h = map.getHeight();

        if (nx == px && ( (py + 1) % h ) == ny)
            return Game.UP;
        else if (nx == px && ( (py - 1 + h) % h ) == ny)
            return Game.DOWN;
        else if (ny == py && ( (px - 1 + w) % w ) == nx)
            return Game.LEFT;
        else if (ny == py && ( (px + 1) % w ) == nx)
            return Game.RIGHT;

        return Game.STAY;
    }

}